public class Ej01 {
    public static void main(String[] args) {
        int[] array = new int[20];
        //Se genera el array.
        for(int i = 0; i < 20; i++){
            array[i] = (int)((Math.random()*100)+1);
        }
        int[] arrayFinal = new int[10];
        arrayFinal = clasificaArray100(array);
        String fraseOut = "";
        // Se asocian las frases según los rangos.
        for(int i = 0; i < 10; i++){
            if(i == 0){
                fraseOut= "Del 1 al 10 hay ";
            }
            if(i == 1){
                fraseOut= "Del 10 al 20 hay ";
            }
            if(i == 2){
                fraseOut= "Del 20 al 30 hay ";
            }
            if(i == 3){
                fraseOut= "Del 30 al 40 hay ";
            }
            if(i == 4){
                fraseOut= "Del 40 al 50 hay ";
            }
            if(i == 5){
                fraseOut= "Del 50 al 60 hay ";
            }
            if(i == 6){
                fraseOut= "Del 60 al 70 hay ";
            }
            if(i == 7){
                fraseOut= "Del 70 al 80 hay ";
            }
            if(i == 8){
                fraseOut= "Del 80 al 90 hay ";
            }
            if(i == 9){
                fraseOut= "Del 90 al 100 hay ";
            }
            //Se imprimen las frases según el rango y las cifras.
            System.out.println(fraseOut + arrayFinal[i] + " cifra/s");
        }
    }

        public static int[] clasificaArray100(int[] array){
            //Se clasifican las cifras que hay en el array y se mandan al main.
            int[] arrayFinal = new int[10];
            for(int i = 0; i < 20; i++){
                if(array[i] > 0 && array[i] <= 10){
                    arrayFinal[0] += 1;
                }
                if(array[i] > 10 && array[i] <= 20){
                    arrayFinal[1] += 1;
                }
                if(array[i] > 20 && array[i] <= 30){
                    arrayFinal[2] += 1;
                }
                if(array[i] > 30 && array[i] <= 40){
                    arrayFinal[3] += 1;
                }
                if(array[i] > 40 && array[i] <= 50){
                    arrayFinal[4] += 1;
                }
                if(array[i] > 50 && array[i] <= 60){
                    arrayFinal[5] += 1;
                }
                if(array[i] > 60 && array[i] <= 70){
                    arrayFinal[6] += 1;
                }
                if(array[i] > 70 && array[i] <= 80){
                    arrayFinal[7] += 1;
                }
                if(array[i] > 80 && array[i] <= 90){
                    arrayFinal[8] += 1;
                }
                if(array[i] > 90 && array[i] <= 100){
                    arrayFinal[9] += 1;
                }
            }
            return arrayFinal;
       }

    }