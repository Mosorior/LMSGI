import java.util.Scanner;
public class Ej03 {
    // Este ejercicio podría haberlo hecho con una función, pero no lo he visto necesario porque apenas ahorra líneas.
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.println("Introduzca la dirección de correo electrónico:");

        String correo = s.next();
        boolean valido = true;
        boolean arroba = false;

        // Compruebo que no haya ni arrobas ni puntos al principio ni al final.
        if(correo.charAt(0) == '@' || correo.charAt(0) == '.' || correo.charAt(0) == '-' || correo.charAt(correo.length()-1) == '@' || correo.charAt(correo.length()-1) == '.' || correo.charAt(correo.length()-1) == '-' ){
            valido = false;
        }

        // Si el arroba aparece dos veces, será inválido.
        for(int i = 0; i < correo.length(); i++){
            if(correo.charAt(i) == '@'){
                if(arroba){
                    valido = false;
                }
                if(!arroba){
                arroba = true;
                }
                
            }
            // Si aparece alguna de esos caracteres será inválido.
            if(correo.charAt(i) == 'á' || correo.charAt(i) == 'é' ||correo.charAt(i) == 'í' ||correo.charAt(i) == 'ó' ||correo.charAt(i) == 'ú' ||correo.charAt(i) == 'ñ' || correo.charAt(i) == 'à'|| correo.charAt(i) == 'è'|| correo.charAt(i) == 'ì'|| correo.charAt(i) == 'ò'|| correo.charAt(i) == 'ù'|| correo.charAt(i) == 'ä'|| correo.charAt(i) == 'ë'|| correo.charAt(i) == 'ï'|| correo.charAt(i) == 'ö'|| correo.charAt(i) == 'ü' || correo.charAt(i) == 'Á' || correo.charAt(i) == 'É' ||correo.charAt(i) == 'Í' ||correo.charAt(i) == 'Ó' ||correo.charAt(i) == 'Ú' ||correo.charAt(i) == 'Ñ' || correo.charAt(i) == 'À'|| correo.charAt(i) == 'È'|| correo.charAt(i) == 'Ì'|| correo.charAt(i) == 'Ò'|| correo.charAt(i) == 'Ù'|| correo.charAt(i) == 'Ä'|| correo.charAt(i) == 'Ë'|| correo.charAt(i) == 'Ï'|| correo.charAt(i) == 'Ö'|| correo.charAt(i) == 'Ü'){
                valido = false;
            }
            //Si hay un punto detrás de otro punto es inválido
            if(correo.charAt(i) == '.'){
                if(correo.charAt(i+1) == '.'){
                    valido = false;
                }
            }
            //Si hay puntos o guines delante y detrás del arroba, es inválido.
            if(correo.charAt(i) == '.' && correo.charAt(i+1) == '@'){
                valido = false;
            }
            if(correo.charAt(i) == '.' && correo.charAt(i+1) == '@'){
                valido = false;
            }
            if(correo.charAt(i) == '-' && correo.charAt(i+1) == '@'){
                valido = false;
            }
            if(correo.charAt(i) == '-' && correo.charAt(i+1) == '@'){
                valido = false;
            }
        }

        // Se imprime.
        if(valido){
            System.out.println("El correo introducido es válido.");
        }
        else{
            System.out.println("El correo introducido no es válido.");
        }
    }
}
