public class Ej02 {
    public static void main(String[] args) {
        //Creo un array para cada variable.
        int[] alturaCosta = new int[13];

        int[] alturaEsp = new int[13];

        int[] alturaJap = new int[13];

        int[] alturaMarru = new int[13];
        //Son 10 valores de alturas, los otros 3 son para el máximo, el mínimo y la media.

        //Se llama a la función:

        alturaCosta = alturaPais(alturaCosta);
        alturaEsp = alturaPais(alturaEsp);
        alturaJap = alturaPais(alturaJap);
        alturaMarru = alturaPais(alturaMarru);

        //Se imprime por teclado. Los \t son para una mejor presentación:
        System.out.println();
        System.out.println("\t\tALTURAS");
        System.out.println("-------------------------------------------------------------------------------------------------------------------");
        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t|MED\tMIN\tMAX");
        // Costa Rica:
        System.out.print("C. Rica:\t");
        for(int i = 0; i < 10; i++){
            System.out.print(alturaCosta[i] + "\t");
        }
        System.out.println("|" + alturaCosta[10] + "\t" + alturaCosta[11] + "\t" + alturaCosta[12]);

        //España
        System.out.print("España:\t\t");
        for(int i = 0; i < 10; i++){
            System.out.print(alturaEsp[i] + "\t");
        }
        System.out.println("|" + alturaEsp[10] + "\t" + alturaEsp[11] + "\t" + alturaEsp[12]);

        //Japón
        System.out.print("Japón:\t\t");
        for(int i = 0; i < 10; i++){
            System.out.print(alturaJap[i] + "\t");
        }
        System.out.println("|" + alturaJap[10] + "\t" + alturaJap[11] + "\t" + alturaJap[12]);

        //Marruecos
        System.out.print("Marruecos:\t");
        for(int i = 0; i < 10; i++){
            System.out.print(alturaMarru[i] + "\t");
        }
        System.out.println("|" + alturaMarru[10] + "\t" + alturaMarru[11] + "\t" + alturaMarru[12]);


    }
    // Función para crear los arrays completos.
    public static int[] alturaPais(int[] altura){
        //En cada array de altura cambio los valores finales para poder escribirlos después comparándolos con un if:
        
        //altura[10] es la media, que la haré a parte, no necesita que la inicie aquí.
        altura[11] = 210; // Valor mínimo, con lo cual, empieza desde lo más alto
        altura[12] = 140; // Valor máximo, con lo cual, empieza desde lo más bajo

         //Variables para operaciones:
        int[] alturaP = new int[10];
        //Se crea el bucle para rellenar con valores aleatorios.
        for(int i = 0; i < 10; i++){
            alturaP[i] = (int) (Math.random() * (211 - 140)) + 140;
            altura[i] = alturaP[i];

            altura[10] = altura[10]+alturaP[i]; // Esto va sumando las cifras para obtener la media.
            // A su vez se comparan los valores para obtener el máximo y el mínimo en el mismo bucle.
            if(alturaP[i] < altura[11]){
                altura[11] = alturaP[i];
            }
            if(alturaP[i] > altura[12]){
                altura[12] = alturaP[i];
            }
        }
        altura[10] = altura[10]/10;
        return altura;

        }

}
