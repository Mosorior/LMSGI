import java.util.Scanner;
public class Ej04 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean correcto = false;
        int numero = 0;
        int decena = 0;
        int unidad = 0;
        boolean exception = false;
        while(!correcto){
            System.out.println("Introduzca un número del 0 al 99:");
            numero = s.nextInt();
            if(numero < 0 || numero > 99){
                correcto= false;
                System.out.println("Número inválido.");
            }
            else{
                correcto = true;
            }
        }
        //Hacemos un switch con las excepciones.
        switch(numero){
            case 0:
            System.out.println("Cero");
            exception = true;
            break;
            case 10:
            System.out.println("Diez");
            exception = true;
            break;
            case 11:
            System.out.println("Once");
            exception = true;
            break;
            case 12:
            System.out.println("Doce");
            exception = true;
            break;
            case 13:
            System.out.println("Trece");
            exception = true;
            break;
            case 14:
            System.out.println("Catorce");
            exception = true;
            break;
            case 15:
            System.out.println("Quince");
            exception = true;
            break;
            case 20:
            System.out.println("Veinte");
            exception = true;
            break;
        }
        // Si no hay excepciones sacamos los dígitos y llamamos a las funciones.
        if(!exception){
            decena = numero/10;
            unidad = numero%10;
            if (decena != 0){
                if(decena == 2 || decena == 1){
                    //Si la decena es 2 o 1 (10 y algo y 20 y algo) se imprimen juntas
                    System.out.println(textoDecena(decena) + textoUnidad(unidad));
                }
                else{
                    // Por el contrario se imprime con un "y" para hacer la unión
                    System.out.println(textoDecena(decena) + " y " + textoUnidad(unidad));
                }
            }
            else{
                //Si solo hay unidades, se imprime la unidoad.
                System.out.println(textoUnidad(unidad));
            }
            
        }
        

        
    }
    // En el caso de las decenas se saca el comienzo de la parte de las decenas.
    public static String textoDecena(int decena){
        String textoDecena = "";
        switch(decena){
            case 1:
            textoDecena = "Dieci";
            break;
            case 2:
            textoDecena = "Veinti";
            break;
            case 3:
            textoDecena = "Treinta";
            break;
            case 4:
            textoDecena = "Cuarenta";
            break;
            case 5:
            textoDecena = "Cincuenta";
            break;
            case 6:
            textoDecena = "Sesenta";
            break;
            case 7:
            textoDecena = "Setenta";
            break;
            case 8:
            textoDecena = "Ochenta";
            break;
            case 9:
            textoDecena = "Noventa";
            break;
        }

        return textoDecena;
    }
    // Se sacan los números del 1 al 9, no se tiene en cuenta el 0 porque es una excepción.
    public static String textoUnidad(int unidad){
        String textoUnidad = "";
        switch(unidad){
            case 1:
            textoUnidad = "uno";
            break;
            case 2:
            textoUnidad = "dos";
            break;
            case 3:
            textoUnidad = "tres";
            break;
            case 4:
            textoUnidad = "cuatro";
            break;
            case 5:
            textoUnidad = "cinco";
            break;
            case 6:
            textoUnidad = "seis";
            break;
            case 7:
            textoUnidad = "siete";
            break;
            case 8:
            textoUnidad = "ocho";
            break;
            case 9:
            textoUnidad = "nueve";
            break;
        }
        return textoUnidad;
    }
}
